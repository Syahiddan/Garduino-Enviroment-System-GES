package com.example.shidan.ges.shidan;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;

import com.example.shidan.ges.model.Device;

import java.util.ArrayList;

public class DeviceAdapterList extends ArrayAdapter<Device> {
    private Context mContext;
    private int mResource;
    private ViewHolder holder;

    static class ViewHolder{

    }
    public DeviceAdapterList( Context context, int resource, ArrayList<Device> objects) {
        super(context, resource, objects);
        mContext = context;
        mResource = resource;
    }

    @Override
    public View getView(int position,  View convertView,  ViewGroup parent) {
        final View result;

        if (convertView == null){
            LayoutInflater inflater = LayoutInflater.from(mContext);
            convertView = inflater.inflate(mResource, parent, false);
        }else{
//            holder = (WorkerAdapterList.ViewHolder) convertView.getTag();
            result = convertView;
        }
        return convertView;
    }
}
