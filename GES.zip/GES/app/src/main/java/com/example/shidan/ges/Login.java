package com.example.shidan.ges;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.toolbox.Volley;
import com.example.shidan.ges.model.User;
import com.example.shidan.ges.shidan.InputTextBehaviour;
import com.example.shidan.ges.shidan.Session;
import com.example.shidan.ges.shidan.WebService;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;

public class Login extends AppCompatActivity {

    private EditText et_username, et_password;
    private TextView tv_username, tv_password;
    User curUser;
    AlertDialog ui;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        et_username = (EditText) findViewById(R.id.et_username);
        et_password = (EditText) findViewById(R.id.et_password);

        tv_username = (TextView) findViewById(R.id.tv_username);
        tv_password = (TextView) findViewById(R.id.tv_password);

        Button login = (Button) findViewById(R.id.btn_login);

        InputTextBehaviour username = new InputTextBehaviour("standard", et_username, tv_username);
        username.startBehaviour();
    }

    public void changePasswordState(View v) {
        Button lol = (Button) findViewById(v.getId());

        if (et_password.getInputType() == (InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD)) {
            et_password.setInputType(InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
            lol.setText("uh");
            et_password.setSelection(et_password.length());
        } else {
            et_password.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
            lol.setText("h");
            et_password.setSelection(et_password.length());
        }


    }

    public void loginState(View v) {


        String username = et_username.getText().toString();
        String password = et_password.getText().toString();

        username = username.trim();
        password = password.trim();

        try {
            InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);

        } catch (Exception e) {

        }

        final HashMap<Object, Object> cubeString = new HashMap<Object, Object>();

        if (!username.isEmpty() && !password.isEmpty()) {
            ui = new AlertDialog.Builder(this).setView(R.layout.loading).show();
            cubeString.put("function", "fnLogin");
            cubeString.put("username", username);
            cubeString.put("pass", password);

            final WebService cube1 = new WebService(getApplicationContext());
            Thread loginThread = new Thread(){
                @Override
                public void run() {
                    cube1.post("", cubeString, new WebService.JSON() {
                        @Override
                        public void responseData(JSONObject Status,JSONObject data) {
                            try {
//                        Toast.makeText(getApplicationContext(),data.getString("status"),Toast.LENGTH_SHORT).show();
                                if (data.getString("status").equals("valid")) {
                                    JSONObject data_temp = data.getJSONObject("data");
                                    curUser = new User(data_temp.optString("worker_id"), data_temp.optString("worker_type"), data_temp.optString("fname"), data_temp.optString("midname"), data_temp.optString("lname"), data_temp.optString("email"), data_temp.optString("phone"), data_temp.optString("address"), data_temp.getInt("postcode"), data_temp.optString("state"), data_temp.optString("country"));
                                    Session.setUser(curUser);
                                    if (data_temp.getString("worker_type").equals("A") || data_temp.getString("worker_type").equals("a")) {
//                                Toast.makeText(getApplicationContext(),"Admin oi",Toast.LENGTH_SHORT).show();
                                        Intent jumpToAdminPage = new Intent(getApplicationContext(), Admin.class);

                                        startActivity(jumpToAdminPage);
                                        ui.dismiss();
                                        finish();
                                    } else if (data_temp.getString("worker_type").equals("W") || data_temp.getString("worker_type").equals("w")) {
                                        Toast.makeText(getApplicationContext(), "Worker oi", Toast.LENGTH_SHORT).show();
                                        ui.dismiss();

                                    }

                                } else {
                                    Toast.makeText(getApplicationContext(), "Invalid Username and Password", Toast.LENGTH_SHORT).show();
                                }
                            } catch (JSONException e) {
                                ui.dismiss();
                                Toast.makeText(getApplicationContext(), "Internet not available", Toast.LENGTH_SHORT).show();
                            }

                        }
                    }, "");
                }
            };
            loginThread.start();

        } else {

            if (username.isEmpty()) {
                Toast.makeText(getApplicationContext(), "no username", Toast.LENGTH_SHORT).show();
            }
            if (password.isEmpty()) {
                Toast.makeText(getApplicationContext(), "no password ", Toast.LENGTH_SHORT).show();
            }
        }


    }
}
